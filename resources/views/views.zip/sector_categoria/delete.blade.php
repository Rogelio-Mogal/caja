@extends('layouts.app')

@section('content')
@section('title','Eliminar sector/categoría')
	@include('sector_categoria._detalle', ['btnEnviar' => 'Guardar'])
@stop