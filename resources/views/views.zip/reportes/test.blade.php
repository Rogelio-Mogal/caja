<ul>
	<li>{{$user->id}}</li>
	<li>{{$user->name}}</li>
	<li>{{$user->apat}}</li>
	<li>{{$user->amat}}</li>
	<li>{{$user->curp}}</li>
	<li>{{$user->email}}</li>
	<li>{{$user->activo}}</li>

</ul>