@extends('layouts.app')

@section('content')
@section('title','Eliminar socio')
	@include('socios._detalle', ['btnEnviar' => 'Guardar'])
@stop