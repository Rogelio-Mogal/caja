<a href="/">
    <img class="masthead-avatar mb-5" src="{{ asset('image/caja.png') }}"  style="height: 200px;" alt="SSPO_logo" />
</a>
